import InvoiceEditor from "@/app/components/invoices/InvoiceEditor";

export default function App() {
  return <InvoiceEditor />;
}