
  # WYSIWYG Invoice Editor UI

  This is a code bundle for WYSIWYG Invoice Editor UI. The original project is available at https://www.figma.com/design/GXbA0HZ1yBI8l1u9JLtlHy/WYSIWYG-Invoice-Editor-UI.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  