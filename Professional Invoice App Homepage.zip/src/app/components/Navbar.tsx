import { motion } from "motion/react";

export function Navbar() {
  return (
    <nav className="fixed top-0 left-0 right-0 z-50 bg-black border-b border-white/10">
      <div className="mx-auto max-w-7xl px-8">
        <div className="flex h-16 items-center justify-between">
          <span className="text-xl tracking-tight text-white">Invozify</span>
          
          <div className="flex items-center gap-6">
            <a 
              href="#features" 
              className="hidden md:block text-sm text-gray-400 hover:text-white transition-colors"
            >
              Features
            </a>
            <a 
              href="#pricing" 
              className="hidden md:block text-sm text-gray-400 hover:text-white transition-colors"
            >
              Pricing
            </a>
            <a 
              href="#login" 
              className="text-sm text-gray-400 hover:text-white transition-colors"
            >
              Log In
            </a>
            <motion.a
              href="#download"
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              className="px-5 py-2 bg-white text-black rounded-lg text-sm font-medium hover:bg-gray-100 transition-colors"
            >
              Get Started
            </motion.a>
          </div>
        </div>
      </div>
    </nav>
  );
}
