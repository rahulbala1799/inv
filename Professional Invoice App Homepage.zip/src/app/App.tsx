import { Navbar } from "@/app/components/Navbar";
import { Hero } from "@/app/components/Hero";
import { WhatThisIs } from "@/app/components/WhatThisIs";
import { HowItWorks } from "@/app/components/HowItWorks";
import { Speed } from "@/app/components/Speed";
import { MobileApps } from "@/app/components/MobileApps";
import { Testimonials } from "@/app/components/Testimonials";
import { ComingSoon } from "@/app/components/ComingSoon";
import { Pricing } from "@/app/components/Pricing";
import { WhoFor } from "@/app/components/WhoFor";
import { Footer } from "@/app/components/Footer";

export default function App() {
  return (
    <div className="bg-white antialiased">
      <Navbar />
      <Hero />
      <WhatThisIs />
      <HowItWorks />
      <Speed />
      <MobileApps />
      <Testimonials />
      <ComingSoon />
      <Pricing />
      <WhoFor />
      <Footer />
    </div>
  );
}
